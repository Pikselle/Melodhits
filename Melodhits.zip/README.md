BONJOUR ET BIENVENUE

Pour lancer cette application incroyable, il suffit d'installer les modules nécessaires (indiqués dans "requirements.txt") et de lancer le fichier "index.py" !
